﻿namespace JohnHoffmanPrinslooST10082027C_POEpart1
{
    internal class Program
    {
        private static SanelesCommandLineRecipeBookApplication sclrbaObject = new SanelesCommandLineRecipeBookApplication();

        static void Main(string[] args)
        {
            sclrbaObject.UserInterface();
        }
    }
}
