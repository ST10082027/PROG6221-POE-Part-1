﻿using System;

namespace JohnHoffmanPrinslooST10082027C_POEpart1
{
    public class SanelesCommandLineRecipeBookApplication
    {
        //Variables
        //Integers
        private int numIngredients;
        private int numSteps;
        //Doubles
        private double[] ingredientQuantities;
        private double scaleFactor = 1;
        //Strings
        private string[] ingredientNames;
        private string[] ingredientUnits;
        private string[] stepDescriptions;

        public void UserInterface()
        /*This method acts as the main interaction loop for the application. It continuously displays a menu to the user, reads their choice,
         * and invokes corresponding functionality based on the user's selection. This is the entry point for user commands to enter, display,
         * scale, reset, clear recipes, or exit the program.*/
        {
            while (true)
            {
                Console.WriteLine("==========================================");
                Console.WriteLine("Recipe Book");
                Console.WriteLine("==========================================");
                Console.WriteLine("1. Enter a new recipe\n2. Display the recipe\n3. Scale the recipe\n4. Reset the quantities\n5. Clear the recipe\n6. Exit");
                Console.WriteLine("==========================================");

                int choice = ReadPositiveInteger("Select an option: ");
                switch (choice)
                {
                    case 1: EnterRecipe(); break;
                    case 2: DisplayRecipe(); break;
                    case 3: ScaleRecipe(); break;
                    case 4: ResetQuantities(); break;
                    case 5: ClearRecipe(); break;
                    case 6: Console.WriteLine("Goodbye!"); return;
                    default: InvalidInputErrorMessage(); break;
                }
            }
        }

        public void EnterRecipe()
        /*Facilitates the user in entering a new recipe. It collects the number of ingredients and the number of preparation steps, then
         * initializes arrays to hold ingredient details and step descriptions by calling respective initialization methods.*/
        {
            numIngredients = ReadPositiveInteger("Enter the number of ingredients: ");
            InitializeIngredients();
            numSteps = ReadPositiveInteger("Enter the number of steps: ");
            InitializeSteps();
        }

        public void DisplayRecipe()
         /*Displays the current recipe's ingredients and preparation steps. If no recipe is entered, it shows an error message. Ingredients
          *are shown with their quantities adjusted by the current scale factor.*/
        {
            if (numIngredients == 0 && numSteps == 0)
            {
                NoRecipeFoundErrorMessage();
                return;
            }

            Console.WriteLine("==========================================");
            Console.WriteLine("Ingredients:");
            for (int i = 0; i < numIngredients; i++)
            {
                Console.WriteLine($"{ingredientQuantities[i] * scaleFactor} {ingredientUnits[i]} {ingredientNames[i]}");
            }
            Console.WriteLine("\nSteps:");
            for (int i = 0; i < numSteps; i++)
            {
                Console.WriteLine($"{i + 1}. {stepDescriptions[i]}");
            }
            PressEnterToContinue();
        }

        public void ScaleRecipe()
        /*Allows the user to scale the quantities of the ingredients of the current recipe by a selected factor. The user can choose predefined
         *scale factors (0.5x, 2x, 3x) or enter a custom scale factor. If no ingredients are loaded, an error message is displayed.*/
        {
            if (numIngredients == 0)
            {
                NoRecipeFoundErrorMessage();
                return;
            }
            Console.WriteLine("==========================================");
            Console.WriteLine("Select a scaling factor:");
            Console.WriteLine("1. 0.5x\n2. 2x\n3. 3x\n4. Custom");
            Console.WriteLine("==========================================");
            scaleFactor = ReadScaleFactor();
            DisplayScaledRecipe();
            PressEnterToContinue();
        }

        public void ResetQuantities()
        /*Prompts the user to enter new quantities for each ingredient of the current recipe. This method updates the quantities directly, and if
         *there are no ingredients loaded, it shows an error message.*/
        {
            if (numIngredients == 0)
            {
                NoRecipeFoundErrorMessage();
                return;
            }
            UpdateQuantities();
            Console.WriteLine("Recipe quantities have been reset.");
            PressEnterToContinue();
        }

        public void ClearRecipe()
        /*Clears all the data related to the current recipe, including ingredients and preparation steps. It resets all relevant arrays and counters.
         *If no recipe data exists when called, an error message is displayed.*/
        {
            if (numIngredients == 0 && numSteps == 0)
            {
                NoRecipeFoundErrorMessage();
                return;
            }
            numIngredients = 0;
            ingredientNames = null;
            ingredientQuantities = null;
            ingredientUnits = null;
            numSteps = 0;
            stepDescriptions = null;
            Console.WriteLine("Recipe cleared.");
            PressEnterToContinue();
        }

        private int ReadPositiveInteger(string prompt)
        /*A utility method that prompts the user with a provided string and reads an input from the console. It ensures the input is a positive integer.
         *This method is used across various functionalities that require positive integer input.*/
        {
            Console.Write(prompt);
            while (true)
            {
                if (int.TryParse(Console.ReadLine(), out int result) && result > 0)
                {
                    return result;
                }
                Console.WriteLine("Invalid input. Please enter a positive integer.");
            }
        }

        private double ReadPositiveDouble(string prompt)
        /*Similar to ReadPositiveInteger, this method prompts the user and ensures that the input is a positive double. It's used when entering or updating
         *ingredient quantities that may include fractional parts.*/
        {
            Console.Write(prompt);
            while (true)
            {
                if (double.TryParse(Console.ReadLine(), out double value) && value >= 0)
                {
                    return value;
                }
                Console.WriteLine("Invalid input. Please enter a non-negative number.");
            }
        }

        private string ReadString(string prompt)
        /*Reads a string input from the user following a prompt. This method is commonly used to gather textual data such as ingredient names and unit types,
         *or step descriptions.*/
        {
            Console.Write(prompt);
            return Console.ReadLine();
        }

        private void InitializeIngredients()
        /*Initializes the arrays that hold the names, quantities, and units of ingredients using the user's input. It calls ReadString and ReadPositiveDouble
         *for name and quantity inputs, respectively.*/
        {
            ingredientNames = new string[numIngredients];
            ingredientQuantities = new double[numIngredients];
            ingredientUnits = new string[numIngredients];

            for (int i = 0; i < numIngredients; i++)
            {
                ingredientNames[i] = ReadString($"Enter the name of ingredient {i + 1}: ");
                ingredientQuantities[i] = ReadPositiveDouble($"Enter the quantity of ingredient {i + 1}: ");
                ingredientUnits[i] = ReadString($"Enter the unit of measurement for ingredient {i + 1}: ");
            }
        }

        private void InitializeSteps()
        /*Initializes the array that holds the descriptions of the preparation steps. It gathers input for each step through the ReadString method.*/
        {
            stepDescriptions = new string[numSteps];
            for (int i = 0; i < numSteps; i++)
            {
                stepDescriptions[i] = ReadString($"Enter the description for step {i + 1}: ");
            }
        }

        private double ReadScaleFactor()
        /*Reads the user's choice for a scaling factor and returns the corresponding numerical value. It prompts until a valid choice is made between
         *predefined options or allows the entry of a custom scaling factor.*/
        {
            while (true)
            {
                int choice = ReadPositiveInteger("Choose an option (1-4): ");
                switch (choice)
                {
                    case 1: return 0.5;
                    case 2: return 2;
                    case 3: return 3;
                    case 4:
                        return ReadPositiveDouble("Enter a custom scaling factor: ");
                    default:
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 4.");
                        break;
                }
            }
        }

        private void DisplayScaledRecipe()
        /*Reads the user's choice for a scaling factor and returns the corresponding numerical value. It prompts until a valid choice is made between predefined 
         *options or allows the entry of a custom scaling factor.*/
        {
            Console.WriteLine("\nScaled Recipe:");
            for (int i = 0; i < numIngredients; i++)
            {
                double scaledQuantity = ingredientQuantities[i] * scaleFactor;
                Console.WriteLine($"{scaledQuantity} {ingredientUnits[i]} {ingredientNames[i]}");
            }
        }

        private void UpdateQuantities()
        /*Allows the user to input new quantities for each ingredient in the recipe. It calls ReadPositiveDouble for each ingredient to collect the new values.*/
        {
            for (int i = 0; i < numIngredients; i++)
            {
                ingredientQuantities[i] = ReadPositiveDouble($"New quantity for {ingredientNames[i]} ({ingredientUnits[i]}): ");
            }
        }

        private void NoRecipeFoundErrorMessage()
        /*Displays a generic error message when an operation that requires a recipe is attempted but no recipe data is available.*/
        {
            Console.WriteLine("No recipe found. Please enter a recipe and try again.");
            PressEnterToContinue();
        }

        private void InvalidInputErrorMessage()
        /*Displays a message when the user inputs an invalid selection in the main menu.*/
        {
            Console.WriteLine("Invalid choice. Please enter a number between 1 and 6.");
            PressEnterToContinue();
        }

        private void PressEnterToContinue()
        /*A simple utility that pauses program execution and waits for the user to press any key, providing a break before continuing or returning to the
         *main menu.*/
        {
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }
    }
}
